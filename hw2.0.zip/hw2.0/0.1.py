s = []
a=0
s=input()
a=(len(s))
a=a*23
x=a//100
y=a%100
print(x,'р.',y,'коп.')
