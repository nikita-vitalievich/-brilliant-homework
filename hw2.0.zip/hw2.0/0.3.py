a=int(input())
b=int(input())
c=int(input())
d=int(input())
if (a+2==c and b+5==d) or (a-2==c and b-5==d) or (a+2==c and b-5==d) or (a-2==c and b+5==d) or(a+5==c and b+2==d) or (a-5==c and b-2==d) or(a+5==c and b-2==d) or (a-5==c and b+2==d):
    print('YESSSS!')
else:
    print('No no')
